"""MOOD game"""
