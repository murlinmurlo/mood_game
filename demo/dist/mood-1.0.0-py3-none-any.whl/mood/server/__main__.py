"""MOOD server"""

from . import main
import asyncio


asyncio.run(main())
