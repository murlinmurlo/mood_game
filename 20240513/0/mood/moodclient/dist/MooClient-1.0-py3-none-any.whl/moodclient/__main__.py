from .client import main

main()
