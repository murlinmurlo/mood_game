from asyncio import run
from .server import main

run(main())
